<?php
/**
 * 后台公共导航栏组件
 *
 * 用法：在页面 <body> 标签之后设置 $active_page 并 include 此文件
 *   <?php $active_page = 'index'; include __DIR__ . '/components/navbar.php'; ?>
 *
 * 可选变量：
 *   $brand_text  自定义品牌文字（默认"后台管理"）
 *   $brand_icon  自定义品牌图标（默认 fas fa-cog）
 */
if (!defined('ADMIN_NAVBAR_LOADED')) {
    define('ADMIN_NAVBAR_LOADED', true);
}

$active      = $active_page ?? '';
$brand       = $brand_text ?? '后台管理';
$brand_icon  = $brand_icon ?? 'fas fa-cog';

// 统一菜单项（顺序、链接、图标、文字全站一致）
$nav_items = [
    ['key' => 'index',         'url' => 'index.php',         'icon' => 'fas fa-comments',     'text' => '反馈管理'],
    ['key' => 'versions',      'url' => 'versions.php',      'icon' => 'fas fa-code-branch',  'text' => '版本管理'],
    ['key' => 'beta_auth',     'url' => 'beta_auth.php',     'icon' => 'fas fa-vial',         'text' => '内测授权'],
    ['key' => 'announcements', 'url' => 'announcements.php', 'icon' => 'fas fa-bullhorn',     'text' => '公告管理'],
    ['key' => 'stats',         'url' => 'stats_v2.php',      'icon' => 'fas fa-chart-line',   'text' => '数据统计'],
    ['key' => 'file_manage',   'url' => 'file_manage.php',   'icon' => 'fas fa-file-code',    'text' => '文件管理'],
    ['key' => 'patches',       'url' => 'patches.php',       'icon' => 'fas fa-puzzle-piece', 'text' => '增量包'],
    ['key' => 'ops',           'url' => 'ops.php',           'icon' => 'fas fa-cogs',         'text' => '运维中心'],
    ['key' => 'sync',          'url' => 'sync.php',          'icon' => 'fas fa-exchange-alt', 'text' => '数据同步'],
    ['key' => 'pull',          'url' => 'pull.php',          'icon' => 'fas fa-truck-ramp-box', 'text' => '远程日志'],
];
?>
<style>
/* 顶部导航 - 全站统一 */
.navbar {
    background: #00a1d6;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    flex-wrap: wrap;
    gap: 10px;
}
.navbar-brand {
    color: white;
    font-size: 20px;
    font-weight: 600;
    text-decoration: none;
}
.navbar-brand:hover { color: white; }
.nav-actions {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}
.nav-link {
    color: white;
    text-decoration: none;
    padding: 8px 15px;
    background: rgba(255,255,255,0.2);
    transition: background 0.3s;
}
.nav-link:hover {
    background: rgba(255,255,255,0.3);
    color: white;
}
.nav-link.active {
    background: rgba(255,255,255,0.35);
    color: white;
}
</style>
<nav class="navbar">
    <a href="index.php" class="navbar-brand">
        <i class="<?php echo htmlspecialchars($brand_icon); ?>"></i> <?php echo htmlspecialchars($brand); ?>
    </a>
    <div class="nav-actions">
        <?php foreach ($nav_items as $item): ?>
            <a href="<?php echo $item['url']; ?>" class="nav-link<?php echo $active === $item['key'] ? ' active' : ''; ?>">
                <i class="<?php echo $item['icon']; ?>"></i> <?php echo $item['text']; ?>
            </a>
        <?php endforeach; ?>
        <a href="../index.php" class="nav-link">
            <i class="fas fa-home"></i> 返回首页
        </a>
        <a href="logout.php" class="nav-link">
            <i class="fas fa-sign-out-alt"></i> 退出登录
        </a>
    </div>
</nav>
